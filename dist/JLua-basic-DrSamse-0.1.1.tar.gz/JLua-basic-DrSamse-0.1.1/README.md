# JLua - Basic - Package

This package enables Json-like lua usement